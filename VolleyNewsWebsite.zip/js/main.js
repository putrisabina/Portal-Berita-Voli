function loginUser(event) {
  event.preventDefault();
  const username = document.getElementById("username").value;
  alert(`Selamat datang, ${username}!`);
  window.location.href = "../index.html";
}
